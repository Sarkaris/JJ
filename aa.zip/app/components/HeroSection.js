import Image from 'next/image';
const HeroSection = () => {


  return (
    <div className="w-[100%]  h-[530px] max-md:h-[370px] mb-7">
      <Image src="/Banner.webp" width={1920} height={775} priority={true} className='w-full h-full max-md:hidden ' alt="Jarvo Cotton" />
      <Image src="/PhoneBanner.webp" width={900} height={500} priority={true} className='w-full h-full md:hidden ' alt="Jarvo Cotton" />


    </div>
  );
};

export default HeroSection;
