"use client"
import { useEffect, useState } from "react"
import { useRouter } from 'next/navigation'
import Image from "next/image"
import { useAppDispatch} from "../lib/hooks";
import { addToCart } from "../lib/features/counter/counterSlice";
import 'dotenv/config'
import useCart from '../store/allProductDefault'

const AllProducts = () => {
    const { products } = useCart()
    // loading
    const [loading, setLoading] = useState(true)
    const dispatch = useAppDispatch()
    const router = useRouter()
    // const [products, setProducts] = useState([])
    const fetchPosts = useCart((state) => state.fetchPosts)
    const fetchAllProductDataSupabase =  () => {

        // const response = await fetch(`/api/supabase`)
        // if (response) {
        //     const data = await response?.json()
        //     let arrData = data.Products
        //     setProducts(arrData)
        //     addToCart(arrData)
        // }
                
            }
    useEffect(() => {
        // fetchAllProductDataSupabase()
        fetchPosts()
        setLoading(false)
    }, [])
    
    const handleAddToCart = (item, e) => {
        e.stopPropagation()
        if (typeof item == 'object') {
            dispatch(addToCart(item))
        }
    }
    return (
        <> 
            <div className="flex  justify-center gap-4 max-md:gap-1">
                <span className="w-16 border border-black h-0 top-4 relative max-md:w-7"></span>
                <h1 className="text-3xl font-bold text-center mb-8 max-md:min-w-fit">Premium Products</h1>
                <span className="w-16 border border-black h-0 top-4 relative max-md:w-7"></span>
            </div>


            {/* all products */}
            {loading && <div><Image width={20} unoptimized height={20} src="/loading.gif" className="mx-auto size-20" alt="Loading" /></div>}
            <div className="mx-auto flex flex-row gap-10 flex-wrap  max-md:gap-3 justify-center  max-md:items-center px-10 max-md:px-1 ">

                {products.map((item) => (

                    <div key={item.id} onClick={(e => {
                        router.push(`/product/${item.id}`)
                    })} className=" cursor-pointer  max-md:max-h-fit  border relative max-md:min-w-[45vw] rounded-md overflow-hidden min-w-[30%] max-w-[30%] ">
                        <div>
                            <Image
                            loading="lazy"
                                src={item.image}
                                alt={item.title}
                                width={300}
                                height={960}
                                className="w-full h-96 max-md:min-h-32 max-md:max-h-48 object-contain max-md:object-contain "
                            />

                        </div>
                        <div className=" bg-white bg-opacity-75 p-4 max-md:max-h-[30%] w-full">
                            <span className="font-bold max-md:font-medium text-sm">{item.title}</span>
                            <div className="flex items-center max-md:gap-2 justify-between max-md:flex-col max-md:justify-between max-md:items-start max-md:w-[100%] ">
                                <span className="text-gray-700">₹{item.price}</span>
                                <button type="button" className={` max-xl:w-auto px-2 py-2 text-white bg-gradient-to-br from-red-500 to-red-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium rounded-lg text-xs max-md:text-[12px] max-md:w-full text-center me-2 max-md:py-1 mt-0 max-md:min-w-fit max-md:rounded-[4px] `}  onClick={(e) =>
                                    handleAddToCart(item, e)}>Add to Cart</button>
                            </div>
                            {item.sale && <span className="absolute top-0 right-0 bg-red-600 text-white px-2 py-1 text-sm">Sale</span>}
                        </div>
                    </div>
                ))}
            </div>
        </>

    )
}

export default AllProducts