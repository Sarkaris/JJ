'use client'
import { useEffect, useState } from "react";
import Header from "./Header";
import Image from "next/image";
import { useAppDispatch, useAppSelector } from "../lib/hooks";
import { addToCart } from "../lib/features/counter/counterSlice";
import React from 'react';
import AddCart from "./AddCart";
import useCart from '../store/allProductDefault'

const SingleProduct = ({ id }) => {
    const { products } = useCart()
    const dispatch = useAppDispatch()
    const itemsNo = useAppSelector(state => state.counter.cart)
    const [sproduct, setSproduct] = useState({})
    const [loading, setLoading] = useState(false)
    const findProduct = async () => {
        const response = await fetch(`/api/singleProductFind/?id=${id}`)
        const data = await response?.json()
        setSproduct(data?.Product[0])
    }
    const findProduct2 = async () => {
        const response = products.filter(item=>{
            return item.id==id
          }); 
        setSproduct(response[0]);
        
        
    }
    useEffect(() => {
        setLoading(true)
        if(products.length>1){
            findProduct2()
        }else{
            findProduct()

        }
        setLoading(false)
        
    }, [])


    return (
        <>
            <Header />
            <div className="px-4 w-[80%] max-lg:w-[90%]  mx-auto my-auto">
                {/* {!loading ? "" : <img src="/loading.gif" alt="loading..." />} */}
                <div className="container mx-auto flex gap-8 items-center max-md:flex-col">
                    {/* Left Item */}
                    <div className=" p-4 max-md:pt-0 flex flex-col items-center w-[40%] max-md:w-[100%] text-center">
                        <p className="uppercase text-sm tracking-widest  mb-2 ">Special Edition</p>
                        <h2 className="text-4xl max-md:text-lg font-bold mb-6">Refine Your Style</h2>
                        <div className=" border border-gray-300 p-4 rounded-md">
                            {!sproduct.image ? <Image src={"/loading.gif"} width={15} height={15} unoptimized className="rounded-md hover:cursor-zoom-in h-[300px] w-[300px]" alt="image" /> : <Image src={sproduct.image} width={250} height={250} priority className="lg:h-[350px] rounded-md hover:cursor-zoom-in h-[300px] w-[300px]" alt="image" />
                            }
                            {/* <image src="{sproduct.image}" alt="Makeup Collection" className="mb-4" /> */}
                            <p className="uppercase text-sm my-2">Accessories</p>
                            <h3 className="text-2xl max-md:text-xl font-semibold">{sproduct.category}</h3>
                            <p className="text-xl mt-2">₹{sproduct.price}</p>
                        </div>
                    </div>

                    {/* Right Item */}
                    <div className="relative bg-cover bg-center max-md:pt-0 p-8 max-md:px-0 w-[50%] max-md:w-[100%]" >
                        {/* <div className="relative bg-cover bg-center p-8" style={{ backgroundImage: 'url(/path/to/image2.jpg)' }}> */}
                        <div className="absolute max-md:relative inset-0  bg-opacity-50 flex flex-col justify-center p-6 max-md:px-0">
                            <p className="uppercase text-sm  mb-2">Clothing</p>
                            <h3 className="text-3xl md:text-4xl font-bold mb-4 max-md:text-2xl">{sproduct.title}</h3>
                            <p className="text-xl mb-4">₹{sproduct.price}</p>
                            <p className="text-sm ">{sproduct.rating}/5</p>
                            {/* <p className="text-sm text-gray-400">Skin & Eye Primer<br />A Foundation & Concealer Palette</p> */}
                            <span className="w-full flex max-md:justify-center">
                                <button type="button" className="w-[40%] text-white bg-gradient-to-br from-red-500 to-red-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium rounded-lg text-sm  text-center me-2 mt-6 max-md:mr-6 px-6 py-2.5 ">Buy Now</button>
                                <AddCart sproduct={sproduct} />
                            </span>
                            <p className="text-sm mt-16"><span className="text-base">Product Details </span><br />{sproduct.description}</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default SingleProduct