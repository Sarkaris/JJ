import React from 'react';
import dynamic from 'next/dynamic';

const Header = dynamic(()=> import('../components/Header'))


const contact = () => {

  return (
    <>
      <Header />
      <div>Contact Us</div>
    </>
  )


}

export default contact;
